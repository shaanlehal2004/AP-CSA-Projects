/**
Land (#8 on Pset)
* @author MonicaChan
* @version 1.0
*/
public abstract class Land extends Transport{
  public Land(int t, double p, boolean fe){
    super(t, p, fe);
  }

}
