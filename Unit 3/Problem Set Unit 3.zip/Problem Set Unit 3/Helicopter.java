/**
Helicopter (#8 on Pset)
* @author MonicaChan
* @version 1.0
*/
public class Helicopter extends Air{

  public Helicopter(int t, int  p, boolean fe){
    super(t, p, fe, 0,0,0);
  }
  public Helicopter(int t, int p, boolean fe, int lj, int lb, int perBoat){
    super(t, p, fe, lj, lb, perBoat);
  }


}
