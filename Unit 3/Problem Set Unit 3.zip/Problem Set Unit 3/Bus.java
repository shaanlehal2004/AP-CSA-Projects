/**
Bus (#8 on Pset)
* @author MonicaChan
* @version 1.0
*/
public class Bus extends Land{

  public Bus(int t, double p, boolean fe){
    super(t, p, fe);
  }

}
