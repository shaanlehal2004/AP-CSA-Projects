public class Woman implements Human{
  /**
  * This function will return a string containing Woman eats + the food input.
  * @param food is the food the human will eat.
  */
  public String eat(String food){
    return "Woman eats " + food;
  }
}
