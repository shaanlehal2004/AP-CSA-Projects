/**
Train (#8 on Pset)
* @author MonicaChan
* @version 1.0
*/
public class Train extends Land{

  public Train(int t, double p){
    super(t, p, false);
  }
  public Train(int t, double p, boolean fe){
    super(t, p, fe);
  }


}
