public class Man implements Human{
  /**
  * This function will return a string containing Man eats + the food input.
  * @param food is the food the human will eat.
  */
  public String eat(String food){
    return "Man eats " + food;
  }
}
