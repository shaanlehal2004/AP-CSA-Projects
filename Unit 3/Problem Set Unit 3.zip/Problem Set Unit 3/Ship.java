/**
Ship (#8 on Pset)
* @author MonicaChan
* @version 1.0
*/
public class Ship extends Sea{
  public Ship(int t, int p, boolean fe){
    super(t, p, fe, 0, 0, 0);
  }

}
