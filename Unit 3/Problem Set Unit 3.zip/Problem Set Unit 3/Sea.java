/**
Sea (#8 on Pset)
* @author MonicaChan
* @version 1.0
*/
public abstract class Sea extends WaterSafety{
  public Sea(int t, double p, boolean fe, int lj, int lb, int c){
    super(t, p, fe, lj, lb, c);
  }
}
